# Password Strength Analyzer & Custom Wordlist Generator

Tools:
- Analyze password strength using zxcvbn (if installed) or entropy fallback.
- Generate custom wordlists from user-provided tokens with leetspeak and year/suffix appends.
- CLI (argparse) and optional Tkinter GUI.

## Quick start
1. Create venv and install:
   ```bash
   python -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```
2. (Optional) Download NLTK words:
   ```bash
   python -c "import nltk; nltk.download('words')"
   ```
3. CLI analyze:
   ```bash
   python -m pw_tool.cli analyze -p "P@ssw0rd2024"
   ```
4. Generate wordlist:
   ```bash
   python -m pw_tool.cli gen -t "John" -t "Doe" -t "Fluffy" -o mylist.txt
   ```
5. Run GUI:
   ```bash
   python -m pw_tool.gui
   ```

## Ethics
Use generated wordlists for authorized testing, recovery, or research only.
