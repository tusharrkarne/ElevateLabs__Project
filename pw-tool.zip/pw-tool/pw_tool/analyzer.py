# analyzer.py
import math
try:
    from zxcvbn import zxcvbn
    ZXC_AVAILABLE = True
except Exception:
    ZXC_AVAILABLE = False

CHARSET_SIZES = {
    'lower': 26,
    'upper': 26,
    'digits': 10,
    'symbols': 32
}

def estimate_charset(password):
    has_lower = any(c.islower() for c in password)
    has_upper = any(c.isupper() for c in password)
    has_digits = any(c.isdigit() for c in password)
    has_symbols = any(not c.isalnum() for c in password)
    size = 0
    if has_lower: size += CHARSET_SIZES['lower']
    if has_upper: size += CHARSET_SIZES['upper']
    if has_digits: size += CHARSET_SIZES['digits']
    if has_symbols: size += CHARSET_SIZES['symbols']
    if size == 0:
        size = 95
    return size

def entropy(password):
    size = estimate_charset(password)
    ent = len(password) * math.log2(size)
    return ent

def estimate_crack_time_seconds(entropy_bits, guesses_per_second=1e9):
    guesses = 2 ** (entropy_bits - 1)
    return guesses / guesses_per_second

def analyze(password):
    if ZXC_AVAILABLE:
        res = zxcvbn(password)
        out = {
            "method": "zxcvbn",
            "score": res.get("score"),
            "entropy": res.get("entropy"),
            "crack_time_seconds": res.get("crack_times_seconds", {}).get("offline_fast_hashing_1e9_per_second"),
            "feedback": res.get("feedback"),
            "details": res
        }
        return out
    else:
        ent = entropy(password)
        secs = estimate_crack_time_seconds(ent)
        if ent < 28:
            score = 0
            fb = "Very weak — short or simple. Use longer passphrase with mixed characters."
        elif ent < 36:
            score = 1
            fb = "Weak — could be improved by adding length and variety."
        elif ent < 60:
            score = 2
            fb = "Moderate — consider using a passphrase or more unique characters."
        elif ent < 128:
            score = 3
            fb = "Strong — good for many uses."
        else:
            score = 4
            fb = "Very strong — high entropy."
        out = {
            "method": "entropy",
            "score": score,
            "entropy": ent,
            "crack_time_seconds": secs,
            "feedback": {"warning": None, "suggestions": [fb]},
            "details": {}
        }
        return out
