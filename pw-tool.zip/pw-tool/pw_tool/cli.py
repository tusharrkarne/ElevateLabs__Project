# cli.py
import argparse
from pw_tool.analyzer import analyze
from pw_tool.wordlist import generate, export_list

def main():
    p = argparse.ArgumentParser(prog="pw-tool", description="Password Analyzer & Wordlist Generator")
    sub = p.add_subparsers(dest="cmd")

    a = sub.add_parser("analyze", help="Analyze a password")
    a.add_argument("-p", "--password", required=True, help="Password to analyze")

    g = sub.add_parser("gen", help="Generate custom wordlist")
    g.add_argument("-t", "--token", action="append", required=True, help="Token (name, date, pet). Can be used multiple times.")
    g.add_argument("-o", "--out", default="wordlist.txt", help="Output file")
    g.add_argument("--max-combo", type=int, default=3, help="Max tokens to combine")
    g.add_argument("--no-leet", action="store_true", help="Disable leetspeak variants")
    g.add_argument("--no-years", action="store_true", help="Don't append years")
    g.add_argument("--no-suffixes", action="store_true", help="Don't append suffixes")

    args = p.parse_args()
    if args.cmd == "analyze":
        res = analyze(args.password)
        print("Method:", res["method"])
        print("Score (0-4):", res["score"])
        print("Entropy (bits):", res["entropy"])
        ct = res.get("crack_time_seconds")
        if ct:
            print("Estimated crack time (s):", ct)
        if res.get("feedback"):
            print("Feedback:", res["feedback"])
    elif args.cmd == "gen":
        words = generate(args.token, max_length_combination=args.max_combo,
                         add_years=not args.no_years,
                         add_suffixes=not args.no_suffixes,
                         leet=(not args.no_leet))
        export_list(words, args.out)
        print(f"Wrote {len(words)} entries to {args.out}")
    else:
        p.print_help()

if __name__ == "__main__":
    main()
