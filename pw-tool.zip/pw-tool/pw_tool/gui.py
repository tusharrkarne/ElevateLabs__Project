# gui.py
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pw_tool.analyzer import analyze
from pw_tool.wordlist import generate, export_list

class PWToolGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Password Analyzer & Wordlist Generator")
        self.geometry("700x520")
        self.create_widgets()

    def create_widgets(self):
        frame = ttk.Frame(self); frame.pack(fill="both", expand=True, padx=8, pady=8)
        ttk.Label(frame, text="Password Analyzer").pack(anchor="w")
        self.pw_entry = ttk.Entry(frame, show="*", width=40)
        self.pw_entry.pack(anchor="w")
        ttk.Button(frame, text="Analyze", command=self.do_analyze).pack(anchor="w", pady=4)
        self.analyze_box = tk.Text(frame, height=6)
        self.analyze_box.pack(fill="x", pady=4)

        ttk.Separator(frame, orient="horizontal").pack(fill="x", pady=6)
        ttk.Label(frame, text="Custom tokens (comma separated)").pack(anchor="w")
        self.tokens_entry = ttk.Entry(frame, width=60)
        self.tokens_entry.pack(anchor="w")
        ttk.Button(frame, text="Generate Wordlist", command=self.do_generate).pack(anchor="w", pady=4)
        self.out_entry = ttk.Entry(frame)
        self.out_entry.insert(0, "wordlist.txt")
        self.out_entry.pack(anchor="w")
        self.status = ttk.Label(frame, text="")
        self.status.pack(anchor="w", pady=6)

    def do_analyze(self):
        pwd = self.pw_entry.get().strip()
        if not pwd:
            messagebox.showwarning("Input needed", "Enter a password to analyze")
            return
        res = analyze(pwd)
        self.analyze_box.delete("1.0","end")
        self.analyze_box.insert("end", f"Method: {res['method']}\nScore: {res['score']}\nEntropy: {res['entropy']}\n")
        if res.get("feedback"):
            self.analyze_box.insert("end", f"Feedback: {res['feedback']}\n")

    def do_generate(self):
        tokens_raw = self.tokens_entry.get().strip()
        if not tokens_raw:
            messagebox.showwarning("Input needed", "Enter tokens (comma separated)")
            return
        tokens = [t.strip() for t in tokens_raw.split(",") if t.strip()]
        out = self.out_entry.get().strip() or "wordlist.txt"
        words = generate(tokens)
        export_list(words, out)
        self.status.config(text=f"Wrote {len(words)} entries to {out}")

if __name__ == "__main__":
    app = PWToolGUI()
    app.mainloop()
