# wordlist.py
import itertools
import re

COMMON_YEARS = [str(y) for y in range(1990, 2031)]
COMMON_SUFFIXES = ["!", "@", "#", "123", "2023", "2024"]
LEET_MAP = {
    'a': ['a','4','@'],
    'e': ['e','3'],
    'i': ['i','1','!'],
    'o': ['o','0'],
    's': ['s','5','$'],
    't': ['t','7']
}

def normalize_token(tok):
    t = tok.strip()
    return [t, re.sub(r'\s+', '', t)]

def leet_variants(token, max_variants=20):
    chars = list(token)
    pools = []
    for c in chars:
        low = c.lower()
        if low in LEET_MAP:
            pools.append(LEET_MAP[low])
        else:
            pools.append([c])
    variants = set()
    for prod in itertools.product(*pools):
        cand = ''.join(prod)
        variants.add(cand)
        if len(variants) >= max_variants:
            break
    return list(variants)

def generate(tokens, max_length_combination=3, add_years=True, add_suffixes=True, leet=True):
    normed = []
    for t in tokens:
        normed.extend(normalize_token(t))
    normed = [n for n in dict.fromkeys(normed) if n]
    candidates = set()
    for r in range(1, max_length_combination+1):
        for combo in itertools.permutations(normed, r):
            cand = ''.join(combo)
            candidates.add(cand)
            candidates.add('-'.join(combo))
            candidates.add('_'.join(combo))
            candidates.add(''.join([c.capitalize() if i==0 else c for i,c in enumerate(combo)]))
    to_process = list(candidates)
    if leet:
        for c in to_process:
            for v in leet_variants(c, max_variants=12):
                candidates.add(v)
    final = set()
    for c in candidates:
        final.add(c)
        if add_years:
            for y in COMMON_YEARS[-15:]:
                final.add(c + y)
                final.add(y + c)
        if add_suffixes:
            for s in COMMON_SUFFIXES:
                final.add(c + s)
    out = [x for x in final if len(x) >= 3]
    out.sort(key=lambda s: (-len(s), s))
    return out

def export_list(words, path):
    with open(path, "w", encoding="utf-8") as f:
        for w in words:
            f.write(w + "\n")
